#import "Esp/ImGuiDrawView.h"
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <Foundation/Foundation.h>
#define ICON_FA_COG u8"\uf013"
#define ICON_FA_EXTRA u8"\uf067"
#define ICON_FA_EXCLAMATION_TRIANGLE "\xef\x81\xb1"
#include <iostream>
#include <UIKit/UIKit.h>
#include <vector>
#include "iconcpp.h"
#import "pthread.h"
#include <array>
#include <cmath>
#include <deque>
#include <fstream>
#include <algorithm>
#include <string>
#include <sstream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cstdint>
#include <cerrno>
#include <cctype>
// Imgui library
#import "API/APIClient.h"
#import "JRMemory.framework/Headers/MemScan.h"
#import "Esp/CaptainHook.h"
#import "Esp/ImGuiDrawView.h"
#import "IMGUI/imgui.h"
#import "IMGUI/imgui_internal.h"
#import "IMGUI/imgui_impl_metal.h"
#import "IMGUI/zzz.h"
#include "oxorany/oxorany_include.h"
#import "Helper/Mem.h"
#include "font.h"
#import "Esp/Includes.h"
#import "Helper/Vector3.h"
#import "Helper/Vector2.h"
#import "Helper/Quaternion.h"
#import "Helper/Monostring.h"
#import <Foundation/Foundation.h>
#include "Helper/font.h"
#include "Helper/data.h"
#include "ban.cpp"
ImFont* verdana_smol;
ImFont* pixel_big = {};
ImFont* pixel_smol = {};
#include "Helper/Obfuscate.h"
#import "Helper/Hooks.h"
#import "IMGUI/zzz.h"
#include <OpenGLES/ES2/gl.h>
#include <OpenGLES/ES2/glext.h>
#include <unistd.h>
#include <string.h>
#include "hook/hook.h"
ImVec4 userColor = ImVec4(1.0f, 0.0f, 0.0f, 1.0f);
ImVec4 espv = ImVec4(0.0f, 1.0f, 0.0f, 1.0f);
ImVec4 espi = ImVec4(1.0f, 0.0f, 0.0f, 1.0f);
ImVec4 fovColor = ImVec4(1.0f, 0.0f, 0.0f, 1.0f);
ImVec4 nameColor = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
ImVec4 distanceColor = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
#define timer(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, sec * NSEC_PER_SEC), dispatch_get_main_queue(), ^
#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale
#define UIColorFromHex(hexColor) [UIColor colorWithRed:((float)((hexColor & 0xFF0000) >> 16))/255.0 green:((float)((hexColor & 0xFF00) >> 8))/255.0 blue:((float)(hexColor & 0xFF))/255.0 alpha:1.0]
UIWindow *mainWindow;
UIButton *menuView;
// Ghost Mode Variables


@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@property (nonatomic, strong) UIButton *ghostButtonView;
@property (nonatomic, strong) UISwitch *ghostSwitch;
@end

@implementation ImGuiDrawView
ImFont *_espFont;
ImFont* verdanab;
ImFont* icons;
ImFont* interb;
ImFont* Urbanist;
static bool speedX2 = false;
static bool prevAimKill = false;
static bool aimKill = false;
static bool MenDeal = true;
BOOL hasGhostBeenDrawn = NO;
static bool StreamerMode = true;
bool fakeLagEnabled = false;
bool FastReloadEnabled = true;
bool SpeeeX2Enabled = false;
bool NoRecoilEnabled = false;
bool WallGlowEnabled = false;
bool WallFlyEnabled = false;
bool WallHackEnabled = false;
bool ScopeEnabled = false;
bool BypassEnabled = true;
bool istelekill = false;
bool isfly = false;
bool antiban(void *instance) {
    return false;
}
bool func_ghost = false;

int FUNC_GHOST(void *instance) {
    return 31278;
}
- (void)ghostModeUI {
    if (self.ghostButtonView) return;

    self.ghostButtonView = [[UIButton alloc] initWithFrame:CGRectMake(305, 330, 58, 54)];
    self.ghostButtonView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.2];
    self.ghostButtonView.layer.cornerRadius = 13;
    self.ghostButtonView.clipsToBounds = YES;
    self.ghostButtonView.layer.shadowOpacity = 0;
    self.ghostButtonView.layer.shadowColor = [UIColor clearColor].CGColor;
    self.ghostButtonView.layer.shadowRadius = 0;
    self.ghostButtonView.alpha = 1.0f;

    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 1, 58, 20)];
    label.text = @"Ghost";
    label.font = [UIFont fontWithName:@"CourierNewPS-BoldMT" size:11];
    label.textColor = [UIColor blackColor];
    label.backgroundColor = [UIColor clearColor];
    [self.ghostButtonView addSubview:label];

    self.ghostSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(3.5, 20, 51, 31)];
    self.ghostSwitch.onTintColor = [UIColor purpleColor];
    self.ghostSwitch.thumbTintColor = [UIColor whiteColor];
    self.ghostSwitch.backgroundColor = [UIColor clearColor];
    [self.ghostSwitch addTarget:self action:@selector(ghostSwitchChanged:) forControlEvents:UIControlEventValueChanged];
    [self.ghostButtonView addSubview:self.ghostSwitch];

    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleGhostDrag:)];
    [self.ghostButtonView addGestureRecognizer:panGesture];

    UIWindow *mainWindow = [UIApplication sharedApplication].keyWindow;
    [mainWindow addSubview:self.ghostButtonView];
}

- (void)ghostSwitchChanged:(UISwitch *)sender {
    Vars.EnableGhost = sender.on;
    static bool ghostState = false;
    void* ghostMain = (void*)getRealOffset(ENCRYPTOFFSET("0x102E2ABAC"));    // main ghost effect

    if (sender.on && !ghostState) {
        hook((void*[]){ ghostMain },
             (void*[]){ (void*)FUNC_GHOST },
             1);
        func_ghost = true;
        ghostState = true;
    } else if (!sender.on && ghostState) {
         Unhook(ghostMain);
           func_ghost = false;
        ghostState = false;
    }
}

- (void)handleGhostDrag:(UIPanGestureRecognizer *)gesture {
    UIView *draggedView = gesture.view;
    CGPoint translation = [gesture translationInView:draggedView.superview];
    CGPoint newCenter = CGPointMake(draggedView.center.x + translation.x, draggedView.center.y + translation.y);
    draggedView.center = newCenter;
    [gesture setTranslation:CGPointZero inView:draggedView.superview];
}

- (void)toggleSpeedX2:(BOOL)enable {
    static dispatch_once_t onceToken;
    static vector<void*> results;
    
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x200000000};
    
    if (enable) {
        dispatch_once(&onceToken, ^{
            uint64_t search = 4397530849764387586;
            engine->JRScanMemory(range, &search, JR_Search_Type_ULong);
            results = engine->getAllResults();
        });
        
        uint64_t modify = 4366458311853765201;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_ULong);
        }
    } else {
        uint64_t modify = 4397530849764387586; // Original value
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_ULong);
        }
        onceToken = 0;
        results.clear();
    }
    delete engine;
}

- (void)toggleNoRecoil:(BOOL)enable {
    static dispatch_once_t onceToken;
    static std::vector<void*> results; 

    JRMemoryEngine* engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = { 0x100000000, 0x200000000 }; 

    if (enable) {
        dispatch_once(&onceToken, ^{
            uint64_t search = 1016018816; 
            engine->result->resultBuffer.clear();
            engine->result->count = 0;
            engine->JRScanMemory(range, &search, JR_Search_Type_ULong);
            results = engine->getAllResults();
        });

        uint64_t modify = 0; 
        for (size_t i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_ULong);
        }
    } else {
        uint64_t modify = 1016018816; 
        for (size_t i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_ULong);
        }
        onceToken = 0; 
        results.clear();
    }

    delete engine;
}

- (void)toggleWallGlow:(BOOL)enable {
    static dispatch_once_t onceToken;
    static vector<void*> results;
    
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x160000000};
    
    if (enable) {
        dispatch_once(&onceToken, ^{
            float search = 1.22f;
            engine->JRScanMemory(range, &search, JR_Search_Type_Float);
            results = engine->getAllResults();
        });

        
        float modify = 965.0f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
    } else {
        float modify = 1.22f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
        onceToken = 0;
        results.clear();
    }
    delete engine;
}



- (void)toggleWallFly:(BOOL)enable {
    static dispatch_once_t onceToken;
    static vector<void*> results;
    
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x160000000};
    
    if (enable) {
        dispatch_once(&onceToken, ^{
            float search = 1.5f;
            engine->JRScanMemory(range, &search, JR_Search_Type_Float);
            results = engine->getAllResults();
        });
        
        float modify = 900.0f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
    } else {
        float modify = 1.5f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
        onceToken = 0;
        results.clear();
    }
    delete engine;
}

- (void)toggleWallHack:(BOOL)enable {
    static dispatch_once_t onceToken;
    static vector<void*> results;
    
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x160000000};
    
    if (enable) {
        dispatch_once(&onceToken, ^{
            float search = 2;
            engine->JRScanMemory(range, &search, JR_Search_Type_Float);
            float search1 = 0.10000000149;
            engine->JRNearBySearch(0x20, &search1, JR_Search_Type_Float);
            float search2 = 3;
            engine->JRScanMemory(range, &search2, JR_Search_Type_Float);
            float search3 = 4.2038954e-45;
            engine->JRScanMemory(range, &search3, JR_Search_Type_Float);
            float search4 = 4.2038954e-45;
            engine->JRNearBySearch(0x20, &search4, JR_Search_Type_Float);
            results = engine->getAllResults();
        });
        
        float modify = -99;
        float modify1 = -1;
        float modify2 = -999;
        float modify3 = 1.3998972e-42;
        float modify4 = 1.3998972e-42;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
    } else {
        // Note: Original values not provided in the original code
        // You would need to restore the original values here
        onceToken = 0;
        results.clear();
    }
    delete engine;
}

- (void)toggleScope:(BOOL)enable {
    static dispatch_once_t onceToken;
    static vector<void*> results;
    
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x160000000};
    
    if (enable) {
        dispatch_once(&onceToken, ^{
            float search = 0.03f;
            engine->JRScanMemory(range, &search, JR_Search_Type_Float);
            results = engine->getAllResults();
        });
        
        float modify = 10.0f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
    } else {
        float modify = 0.03f; // Original value
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
        onceToken = 0;
        results.clear();
    }
    delete engine;
}

- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];

    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];

    if (!self.device) abort();

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
   ImGuiStyle& style = ImGui::GetStyle();

// إعدادات النصوص الأساسية
style.Colors[ImGuiCol_Text] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.60f, 0.60f, 0.60f, 0.50f);

// تعريف ألوان بنفسجية
ImVec4 purpleMain = ImVec4(0.58f, 0.15f, 0.65f, 0.85f);      // #9410a6 مع شفافية
ImVec4 purpleHover = ImVec4(0.68f, 0.25f, 0.75f, 0.95f);     // أفتح عند Hover
ImVec4 purpleActive = ImVec4(0.48f, 0.10f, 0.55f, 0.80f);    // أغمق عند Active

// خلفيات شفافة
style.Colors[ImGuiCol_WindowBg] = ImVec4(0.10f, 0.10f, 0.10f, 0.85f);      // شبه شفاف
style.Colors[ImGuiCol_ChildBg] = ImVec4(0.08f, 0.08f, 0.08f, 0.70f);       // أكثر شفافية
style.Colors[ImGuiCol_PopupBg] = ImVec4(0.12f, 0.12f, 0.12f, 0.90f);       // مع شفافية
style.Colors[ImGuiCol_MenuBarBg] = ImVec4(0.15f, 0.15f, 0.15f, 0.80f);

// إطارات وحقول الإدخال
style.Colors[ImGuiCol_FrameBg] = ImVec4(0.15f, 0.15f, 0.15f, 0.60f);
style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.20f, 0.20f, 0.20f, 0.70f);
style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.25f, 0.25f, 0.25f, 0.80f);

// الأزرار
style.Colors[ImGuiCol_Button] = purpleMain;
style.Colors[ImGuiCol_ButtonHovered] = purpleHover;
style.Colors[ImGuiCol_ButtonActive] = purpleActive;

// العناوين
style.Colors[ImGuiCol_TitleBg] = ImVec4(0.08f, 0.08f, 0.08f, 0.80f);
style.Colors[ImGuiCol_TitleBgActive] = purpleMain;
style.Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.08f, 0.08f, 0.08f, 0.60f);

// الرؤوس (Headers)
style.Colors[ImGuiCol_Header] = purpleMain;
style.Colors[ImGuiCol_HeaderHovered] = purpleHover;
style.Colors[ImGuiCol_HeaderActive] = purpleActive;

// التبويبات (Tabs)
style.Colors[ImGuiCol_Tab] = ImVec4(0.15f, 0.15f, 0.15f, 0.80f);
style.Colors[ImGuiCol_TabHovered] = purpleHover;
style.Colors[ImGuiCol_TabActive] = purpleMain;
style.Colors[ImGuiCol_TabUnfocused] = ImVec4(0.10f, 0.10f, 0.10f, 0.80f);
style.Colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.15f, 0.15f, 0.15f, 0.90f);

// شريط التمرير
style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.05f, 0.05f, 0.05f, 0.50f);
style.Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.30f, 0.30f, 0.30f, 0.60f);
style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.40f, 0.40f, 0.40f, 0.80f);
style.Colors[ImGuiCol_ScrollbarGrabActive] = purpleMain;

// عناصر التحكم
style.Colors[ImGuiCol_CheckMark] = purpleMain;
style.Colors[ImGuiCol_SliderGrab] = purpleMain;
style.Colors[ImGuiCol_SliderGrabActive] = purpleActive;

// حدود
style.Colors[ImGuiCol_Border] = ImVec4(0.43f, 0.43f, 0.50f, 0.30f);
style.Colors[ImGuiCol_BorderShadow] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);

// إعدادات الاستدارة (Rounding)
style.WindowRounding = 8.0f;
style.ChildRounding = 8.0f;
style.FrameRounding = 6.0f;
style.PopupRounding = 8.0f;
style.ScrollbarRounding = 6.0f;
style.GrabRounding = 6.0f;
style.TabRounding = 6.0f;

// إعدادات الحدود (Border Size)
style.WindowBorderSize = 1.0f;
style.ChildBorderSize = 1.0f;
style.PopupBorderSize = 1.0f;
style.FrameBorderSize = 1.0f;
style.TabBorderSize = 1.0f;

// المسافات (Padding/Spacing)
style.WindowPadding = ImVec2(10.0f, 8.0f);
style.FramePadding = ImVec2(10.0f, 5.0f);
style.ItemSpacing = ImVec2(8.0f, 4.0f);
style.ItemInnerSpacing = ImVec2(6.0f, 4.0f);

// لتحقيق شفافية أفضل، تأكد من إعداد OpenGL/DirectX بشكل صحيح:
// - تفعيل blending: glEnable(GL_BLEND);
// - إعداد blending function: glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);











    static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0 };
    ImFontConfig icons_config;
    ImFontConfig CustomFont;
    CustomFont.FontDataOwnedByAtlas = false;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    io.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Custom), sizeof(Custom), 21.f, &CustomFont);
    io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 19.0f, &icons_config, icons_ranges);
    io.Fonts->AddFontDefault();
    ImFont* font = io.Fonts->AddFontFromMemoryTTF(sansbold, sizeof(sansbold), 21.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());
    verdana_smol = io.Fonts->AddFontFromMemoryTTF(verdana, sizeof verdana, 40, NULL, io.Fonts->GetGlyphRangesCyrillic());
    pixel_big = io.Fonts->AddFontFromMemoryTTF((void*)smallestpixel, sizeof smallestpixel, 400, NULL, io.Fonts->GetGlyphRangesCyrillic());
    pixel_smol = io.Fonts->AddFontFromMemoryTTF((void*)smallestpixel, sizeof smallestpixel, 10*2, NULL, io.Fonts->GetGlyphRangesCyrillic());
    ImGui_ImplMetal_Init(_device);

    return self;
}

+ (void)showChange:(BOOL)open {
    MenDeal = open;
}

+ (BOOL)isMenuShowing {
    return MenDeal;
}

- (MTKView *)mtkView {
    return (MTKView *)self.view;
}

void CustomCheckbox(const char* label, bool* v, ImVec4* userColor)
{
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImVec2 p = ImGui::GetCursorScreenPos();
    
    ImVec2 size = ImVec2(26.0f, 26.0f); // tamanho do quadrado
    float rounding = 5.0f;

    ImGui::PushID(label);
    if (ImGui::InvisibleButton("##cbold", size))
        *v = !*v;

    ImVec4 bgColor = ImVec4(0.12f, 0.12f, 0.12f, 0.54f);
    ImU32 fillColor = ImGui::ColorConvertFloat4ToU32(*v ? *userColor : bgColor);

    draw->AddRectFilled(p, ImVec2(p.x + size.x, p.y + size.y), fillColor, rounding);
    ImU32 borderColor = IM_COL32(60, 60, 60, 255);
    draw->AddRect(p, ImVec2(p.x + size.x, p.y + size.y), borderColor, rounding, 0, 1.0f);

    // alinhar texto verticalmente no centro da checkbox
    ImGui::SameLine();
    float textHeight = ImGui::GetTextLineHeight();
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + (size.y - textHeight) * 0.5f);
    ImGui::TextUnformatted(label);

    ImGui::PopID();
}


void SeparatorCustom(float width, float thickness, ImVec4 userColor)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return;

    ImVec2 pos = window->DC.CursorPos;
    float avail_width = ImGui::GetContentRegionAvail().x;

    if (width > avail_width)
        width = avail_width;

    ImGui::Dummy(ImVec2(width, thickness));

    ImU32 col = ImGui::GetColorU32(userColor);

    ImVec2 p1 = pos;
    ImVec2 p2 = ImVec2(pos.x + width, pos.y);

    window->DrawList->AddLine(p1, p2, col, thickness);
}



- (void)loadView
{
    CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
    CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
    self.view.multipleTouchEnabled = YES;
((MTKView *)self.view).multipleTouchEnabled = YES;
self.view.multipleTouchEnabled = YES;
    self.mtkView.multipleTouchEnabled = YES;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;

    self.view.multipleTouchEnabled = YES;
    self.mtkView.multipleTouchEnabled = YES;
}

#pragma mark - Interaction

- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if ([ImGuiDrawView isMenuShowing]) { [self updateIOWithTouchEvent:event]; }
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if ([ImGuiDrawView isMenuShowing]) { [self updateIOWithTouchEvent:event]; }
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if ([ImGuiDrawView isMenuShowing]) { [self updateIOWithTouchEvent:event]; }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if ([ImGuiDrawView isMenuShowing]) { [self updateIOWithTouchEvent:event]; }
}




// أضف قبل drawInMTKView

#pragma mark - MTKViewDelegate

- (void)drawInMTKView:(MTKView*)view
{
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;

    CGFloat framebufferScale = view.window.screen.nativeScale ?: UIScreen.mainScreen.nativeScale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 60);



    
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
        
    hideRecordTextfield.secureTextEntry = StreamerMode;

    if (MenDeal == true) 
    {
        [self.view setUserInteractionEnabled:YES];
        [self.view.superview setUserInteractionEnabled:YES];
        [menuTouchView setUserInteractionEnabled:YES];
    } 
    else if (MenDeal == false) 
    {
        [self.view setUserInteractionEnabled:NO];
        [self.view.superview setUserInteractionEnabled:NO];
        [menuTouchView setUserInteractionEnabled:NO];
    }


    MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
    if (renderPassDescriptor != nil) 
    {
        id<MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
[renderEncoder pushDebugGroup:@"ImGui Jane"];

    ImGui_ImplMetal_NewFrame(renderPassDescriptor);
ImGui::NewFrame();
ImGuiStyle& style = ImGui::GetStyle();
ImFont* font = ImGui::GetFont();
font->Scale = 16.f / font->FontSize;
// Arredondar os cantos da janela
style.WindowRounding = 12.0f; // valor padrão é 0.0f (sem arredondamento)

// Centraliza a janela na tela
CGFloat x = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width) - 400) / 2;
CGFloat y = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height) - 280) / 2;

ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver);
ImGui::SetNextWindowSize(ImVec2(400, 280), ImGuiCond_FirstUseEver);

if (MenDeal == true)
{
    ImGui::SetNextWindowSize(ImVec2(400, 280), ImGuiCond_Always); // Tamanho fixo da janela
    ImGui::Begin(ENCRYPT("  EXCELSIOR XITADO                       "), &MenDeal, ImGuiWindowFlags_NoResize);
            
         ImGui::Columns(2, "MainColumns", false);
ImGui::SetColumnWidth(0, 63.0f); // +3 pra compensar o aumento de largura

// variável de seleção
static int selected_tab = 0;

// Botões colados (sem espaçamento)
ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));
ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(0, 6));

// Mantém a mesma altura e aumenta só um pouco a largura
float buttonWidth = 50.0f;   // antes era 45 → +5 pixels mais largo
float buttonHeight = 57.0f;  // mesmo tamanho de altura

// Leve ajuste de alinhamento vertical
ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 5);

// Botões laterais colados
if (ImGui::Button(ICON_FA_CROSSHAIRS, ImVec2(buttonWidth, buttonHeight))) {
    selected_tab = 0;
}
if (ImGui::Button(ICON_FA_EYE, ImVec2(buttonWidth, buttonHeight))) {
    selected_tab = 1;
}
if (ImGui::Button(ICON_FA_COG, ImVec2(buttonWidth, buttonHeight))) {
    selected_tab = 2;
}
if (ImGui::Button(ICON_FA_ADDRESS_CARD, ImVec2(buttonWidth, buttonHeight))) {
    selected_tab = 3;
}

//ImGui::PopStyleVar(2); // mantém só este

            ImGui::PopStyleVar(2);

            ImGui::NextColumn(); // Mover para a segunda coluna

            SeparatorCustom(330.0f, 1.0f, userColor);
            ImGui::Spacing();


            // Coluna da direita (conteúdo da aba selecionada)
            ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 5));
            ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(0, 5));

            if (selected_tab == 0) {

                // Conteúdo da aba AIM 

                CustomCheckbox(ENCRYPT(" enable Aim                "), &Vars.Aimbot, &userColor);

                float textWidth = ImGui::CalcTextSize("show fov").x;
float firstCustomCheckboxWidth = ImGui::GetItemRectSize().x;  // Largura do primeiro checkbox
float spacing = ImGui::GetStyle().ItemSpacing.x;

// Posição X = posição atual + largura do primeiro checkbox + espaçamento
ImGui::SameLine(firstCustomCheckboxWidth + 30.0f); // 20 pixels de espaçamento
CustomCheckbox(ENCRYPT(" show fov"), &Vars.isAimFov, &userColor);
                CustomCheckbox(ENCRYPT(" lgnorar          "), &Vars.IgnoreKnocked, &userColor);

float firstCustomCheckboxWidth2 = ImGui::GetItemRectSize().x;
    ImGui::SameLine(firstCustomCheckboxWidth2 + 20.0f);
    CustomCheckbox(ENCRYPT(" force visible"), &Vars.VisibleCheck, &userColor);

                ImGui::PushItemWidth(210);
                ImGui::SliderFloat(ENCRYPT("Aim fov"), &Vars.AimFov, 0.00f, 360.00f, ENCRYPT(" %.1f "), ImGuiSliderFlags_None);
                ImGui::Combo(ENCRYPT("Aim When"), &Vars.AimHitbox, Vars.aimHitboxes, 3);
                ImGui::Text(ENCRYPT("Target Bone"));

                ImGui::RadioButton(ENCRYPT("Aim body  "), &Vars.AimWhen, 1);
                ImGui::SameLine();
                ImGui::RadioButton(ENCRYPT("Aim Head"), &Vars.AimWhen, 0);
                ImGui::PopItemWidth();
            } else if (selected_tab == 1) {
                // Conteúdo da aba ESP

               // ---------------- ESP Opções ---------------- 
{
    ImVec4 backup = style.Colors[ImGuiCol_FrameBg];

    // Checkbox Ativar ESP
if (Vars.espActive)
    style.Colors[ImGuiCol_FrameBg] = userColor;

ImGui::Columns(2, "ESPColumns", false);
ImGui::Checkbox(" ENABLE ESP ", &Vars.Enable);
style.Colors[ImGuiCol_FrameBg] = backup;

    ImGui::SameLine();

    // Checkbox Esconder Painel (sempre visível)
    if (Vars.hidePanel) style.Colors[ImGuiCol_FrameBg] = userColor;
    ImGui::Checkbox("MOD STRIME", &StreamerMode);
    style.Colors[ImGuiCol_FrameBg] = backup;

    // Mostrar painel somente se Ativar ESP está ativo E Esconder Painel desmarcado
    if (Vars.espActive && !Vars.hidePanel) {

        // ---------------- ESP Linha ----------------
if (Vars.lines) style.Colors[ImGuiCol_FrameBg] = userColor;
ImGui::Checkbox(ENCRYPT("ESP LINAS"), &Vars.lines);
style.Colors[ImGuiCol_FrameBg] = backup;

if (Vars.lines) {
    ImGui::SameLine(160); // afastamento ligeiramente maior
    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 8); // ajuste fino
    ImGui::Text("Estilo:");
    ImGui::SameLine();
    const char* opcoes[] = { "Cima", "Baixo" };
    ImGui::SetNextItemWidth(90.0f);
    ImGui::Combo("##LineStyle", &Vars.LineStyle, opcoes, IM_ARRAYSIZE(opcoes));
}

// ---------------- ESP Caixa ----------------
if (Vars.Box) style.Colors[ImGuiCol_FrameBg] = userColor;
ImGui::Checkbox(ENCRYPT("ESP BOOX"), &Vars.Box);
style.Colors[ImGuiCol_FrameBg] = backup;

if (Vars.Box) {
    ImGui::SameLine(160);
    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 8);
    ImGui::Text("Estilo:");
    ImGui::SameLine();
    const char* estilos[] = { "Normal", "Cornered", "Redondo" };
    ImGui::SetNextItemWidth(115.0f);
    ImGui::Combo("##BoxStyle", &Vars.BoxStyle, estilos, IM_ARRAYSIZE(estilos));
}

// ---------------- ESP Nome ----------------
if (Vars.Name) style.Colors[ImGuiCol_FrameBg] = userColor;
ImGui::Checkbox(ENCRYPT("ESP NAMS"), &Vars.Name);
style.Colors[ImGuiCol_FrameBg] = backup;

if (Vars.Name) {
    ImGui::SameLine(160);
    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 8);
    ImGui::Text("Estilo:");
    ImGui::SameLine();
    const char* opcoesNome[] = { "Sem Sombra", "Com Sombra" };
    ImGui::SetNextItemWidth(125.0f);
    ImGui::Combo("##NameStyle", &Vars.NameStyle, opcoesNome, IM_ARRAYSIZE(opcoesNome));
}

// ---------------- ESP Vida ----------------
if (Vars.Health) style.Colors[ImGuiCol_FrameBg] = userColor;
ImGui::Checkbox(ENCRYPT("ESP VIDA"), &Vars.Health);
style.Colors[ImGuiCol_FrameBg] = backup;

if (Vars.Health) {
    ImGui::SameLine(160);
    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 8);
    ImGui::Text("Posição:");
    ImGui::SameLine();
    const char* posicoes[] = { "Esquerda", "Direita" };
    ImGui::SetNextItemWidth(115.0f);
    ImGui::Combo("##HealthPos", &Vars.HealthPos, posicoes, IM_ARRAYSIZE(posicoes));
}

        // ---------------- ESP Esqueleto ----------------
        if (Vars.skeleton) style.Colors[ImGuiCol_FrameBg] = userColor;
        ImGui::Checkbox(ENCRYPT("ESP SELECTION"), &Vars.skeleton);
        style.Colors[ImGuiCol_FrameBg] = backup;
    }
}




                

} else if (selected_tab == 2) {
    // Aba MISC

    // ===== Funções Rage - topo =====
    ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), ICON_FA_EXCLAMATION_TRIANGLE); // Ícone de aviso amarelo
    ImGui::SameLine();
    ImGui::Text(ENCRYPT("MISC"));


float colSpacing = 100.0f; // diminua esse valor pra deixar mais “encostado” (ex: 80.0f)

// Primeira linha
CustomCheckbox(ENCRYPT("Aimkil"), &AimKill, &userColor);
ImGui::SameLine(colSpacing);
CustomCheckbox(ENCRYPT("Aim Silent"), &Vars.SilentAim, &userColor);
ImGui::SameLine(colSpacing * 2);
if (ImGui::Checkbox("Speed x2", &speedX2)) {
    [self toggleSpeedX2: speedX2 ? YES : NO];
}

// Segunda linha
CustomCheckbox(ENCRYPT("No Recoil"), &NoRecoilEnabled, &userColor);

ImGui::SameLine(colSpacing);
CustomCheckbox(ENCRYPT("Up play"), &Vars.UpPlayerOne, &userColor);

ImGui::SameLine(colSpacing * 2);
CustomCheckbox(ENCRYPT("Ghost vip"), &Vars.ShowGhostButton, &userColor);

if (Vars.ShowGhostButton) {
    if (!self.ghostButtonView) {
        [self ghostModeUI];
    }
} else {
    if (self.ghostButtonView) {
        [self.ghostButtonView removeFromSuperview];
        self.ghostButtonView = nil;
    }
}


    // ===== Personalização - abaixo =====
    ImGui::TextColored(ImVec4(0, 1, 0, 1), ICON_FA_BARS);
    ImGui::SameLine();
    ImGui::Text(ENCRYPT(" Personalização"));
ImGui::PushItemWidth(40.0f);
// Ajuste das cores principais
ImGui::ColorEdit4(ENCRYPT("Cor do Painel"), (float*)&userColor, 
                  ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoTooltip | 
                  ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_PickerHueBar);

ImGui::ColorEdit4(ENCRYPT("COLOR ESP VISUAL "), (float*)&espv, 
                  ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoTooltip | 
                  ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_PickerHueBar);

ImGui::ColorEdit4(ENCRYPT("COLOR ESP INVISIBLE "), (float*)&espi, 
                  ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoTooltip | 
                  ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_PickerHueBar);
    ImGuiStyle& style = ImGui::GetStyle();

    style.Colors[ImGuiCol_CheckMark] = userColor;
    style.Colors[ImGuiCol_SliderGrab] = userColor;
    style.Colors[ImGuiCol_SliderGrabActive] = userColor;

    style.Colors[ImGuiCol_TitleBg] = userColor;
    style.Colors[ImGuiCol_TitleBgActive] = userColor;
    style.Colors[ImGuiCol_TitleBgCollapsed] = userColor;
    style.Colors[ImGuiCol_Separator] = userColor;

    style.Colors[ImGuiCol_Button] = userColor;
    style.Colors[ImGuiCol_ButtonHovered] = userColor;
    style.Colors[ImGuiCol_ButtonActive] = userColor;

    style.Colors[ImGuiCol_Tab] = userColor;
    style.Colors[ImGuiCol_TabHovered] = userColor;
    style.Colors[ImGuiCol_TabActive] = userColor;
    style.Colors[ImGuiCol_TabUnfocusedActive] = userColor;

    style.Colors[ImGuiCol_Header] = userColor;
    style.Colors[ImGuiCol_HeaderHovered] = userColor;
    style.Colors[ImGuiCol_HeaderActive] = userColor;

    style.Colors[ImGuiCol_NavHighlight] = userColor;
    style.Colors[ImGuiCol_TextSelectedBg] = userColor;
    style.Colors[ImGuiCol_ScrollbarBg] = userColor;
    style.Colors[ImGuiCol_ScrollbarGrab] = userColor;
    style.Colors[ImGuiCol_ScrollbarGrabHovered] = userColor;
    style.Colors[ImGuiCol_ScrollbarGrabActive] = userColor;


    if (ImGui::Button(ENCRYPT(" FIX LOGIN "))) {
        self.mtkView.hidden = YES;
        MenDeal = NO;
        timer(30) {
            self.mtkView.hidden = NO;
            MenDeal = YES;
        });
    }
}

  else if (selected_tab == 3) {
APIClient *API = [APIClient sharedAPIClient];

NSString *key         = [API getKey];
NSString *expiryDate  = [API getExpiryDate];
NSString *deviceModel = [API getDeviceModel];
NSString *iosVersion  = [[UIDevice currentDevice] systemVersion];

 NSDate *exDate;
                NSDate *formatDate;
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                formatter.locale = [[NSLocale alloc] initWithLocaleIdentifier:NSSENCRYPT("pt")];
                [formatter setDateFormat:NSSENCRYPT("dd-MM-yyyy HH:mm:ss")];
                exDate = [formatter dateFromString:[API getExpiryDate]];
                [formatter setDateFormat:NSSENCRYPT("dd/MM/yyyy HH:mm:ss")];
formatDate = [formatter dateFromString:[API getExpiryDate]];
std::string sRemainingTime([[self remaningTime:[NSDate date] endDate:exDate] UTF8String]);
// Exibição no ImGui
ImGui::Text(ENCRYPT("Dispositivo: %s"), [deviceModel UTF8String]);
ImGui::Text(ENCRYPT("Versão do iOS: %s"), [iosVersion UTF8String]);
ImGui::Text(ENCRYPT("Expira em: %s"), [expiryDate UTF8String]);
ImGui::Text(ENCRYPT("Tempo Restante: %s"), sRemainingTime.c_str());
ImGui::Text(ENCRYPT("Key: %s"), [key UTF8String]);

SeparatorCustom(330.0f, 1.0f, userColor);
ImGui::Text(ENCRYPT("DEVLOPER: DlvXxEXCEL"));
if (ImGui::Button(ENCRYPT(" 𝐭𝐞𝐥𝐞𝐠𝐫𝐚𝐦 "))) {
    NSURL *url = [NSURL URLWithString:[NSString stringWithUTF8String:ENCRYPT("https://t.me/EXCELSIOR_XITADO")]];
    [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
    }
}

            ImGui::PopStyleVar(2);
            ImGui::Columns(1); // Resetar colunas
            ImGui::End();
        }
        
        ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
        get_players();
        aimbot();
        game_sdk->init();
        

if (Vars.isAimFov && Vars.AimFov > 0) {
    ImVec2 center = ImVec2(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y / 2);

    if (Vars.fovaimglow) {
        static float rainbowHue = 0.0f;
        rainbowHue += ImGui::GetIO().DeltaTime * 0.8f;
        if (rainbowHue > 1.0f) rainbowHue = 0.0f;

        drawcircleglow(
            draw_list,
            center,
            Vars.AimFov,
            ImColor(fovColor), // usa cor configurada
            100,
            2.0f,
            12
        );
    } else {
        draw_list->AddCircle(
            center,
            Vars.AimFov,
            ImColor(fovColor),
            100,
            2.0f
        );
    }
}


        ImGui::Render();
        ImDrawData* draw_data = ImGui::GetDrawData();
        ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
        [renderEncoder popDebugGroup];
        [renderEncoder endEncoding];
        [commandBuffer presentDrawable:view.currentDrawable];
        [commandBuffer commit];
    } 
} 

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size {}
void hooking() {
void* address[] = {
               (void*)getRealOffset(ENCRYPTOFFSET("0x1044290AC"))
    };
    void* function[] = {
                (void*)antiban                                                     
    };
            hook(address, function, 1);
}
void *hack_thread(void *) {

    sleep(5);
    hooking();
    pthread_exit(nullptr);
    return nullptr;
}

void __attribute__((constructor)) initialize() {
    pthread_t hacks;
    pthread_create(&hacks, NULL, hack_thread, NULL); 
}

- (NSString*)remaningTime:(NSDate*)startDate endDate:(NSDate*)endDate
{
    NSDateComponents *components;
    NSInteger week;
    NSInteger days;
    NSInteger hour;
    NSInteger minutes;
    NSInteger second;
    NSString *durationString;
    
    components = [[NSCalendar currentCalendar] components: NSCalendarUnitDay|NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond fromDate:startDate toDate:endDate options: 0];
    days = [components day];
    week = round(days / 7);
    hour = [components hour];
    minutes = [components minute];
    second = [components second];
    return [NSString stringWithFormat:@"%ld dia(s), %ld h, %ld min, %ld s",days, hour, minutes, second];
}

@end

